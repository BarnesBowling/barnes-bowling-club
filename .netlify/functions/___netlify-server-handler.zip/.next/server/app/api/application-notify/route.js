var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/application-notify/route.js")
R.c("server/chunks/[root-of-the-server]__10e4sp_._.js")
R.c("server/chunks/node_modules_12serik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_application-notify_route_actions_0avi493.js")
R.m(49355)
module.exports=R.m(49355).exports
