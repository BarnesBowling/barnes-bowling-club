var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/member-session/route.js")
R.c("server/chunks/[root-of-the-server]__0vzho8d._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_member-session_route_actions_0-enfpi.js")
R.m(18406)
module.exports=R.m(18406).exports
