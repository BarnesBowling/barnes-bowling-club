var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[root-of-the-server]__0vffx9i._.js")
R.c("server/chunks/node_modules_12serik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_02158u4.js")
R.m(10044)
module.exports=R.m(10044).exports
