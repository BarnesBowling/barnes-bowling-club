var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/corporate-enquiry/route.js")
R.c("server/chunks/[root-of-the-server]__0k9h51r._.js")
R.c("server/chunks/node_modules_12serik._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/_next-internal_server_app_api_corporate-enquiry_route_actions_0tg4n69.js")
R.m(17980)
module.exports=R.m(17980).exports
