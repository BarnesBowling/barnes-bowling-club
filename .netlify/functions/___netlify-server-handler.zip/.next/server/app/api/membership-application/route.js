var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/membership-application/route.js")
R.c("server/chunks/[root-of-the-server]__0_7-tid._.js")
R.c("server/chunks/node_modules_12serik._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/_next-internal_server_app_api_membership-application_route_actions_085~xm..js")
R.m(92183)
module.exports=R.m(92183).exports
