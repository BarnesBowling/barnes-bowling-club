var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/paypal-capture/route.js")
R.c("server/chunks/[root-of-the-server]__03vv5jx._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0hp37pu._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_payment_paypal-capture_route_actions_0o378w7.js")
R.m(21830)
module.exports=R.m(21830).exports
