var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/paypal-order/route.js")
R.c("server/chunks/[root-of-the-server]__0ba_vsf._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_api_payment_paypal-order_route_actions_0~myfux.js")
R.m(11292)
module.exports=R.m(11292).exports
