var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/members/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0comrr.._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_members_logout_route_actions_0ffcdox.js")
R.m(27906)
module.exports=R.m(27906).exports
