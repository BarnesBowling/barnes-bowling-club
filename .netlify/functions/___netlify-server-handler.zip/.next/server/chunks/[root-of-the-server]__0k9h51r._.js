module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},17980,e=>{"use strict";var t=e.i(47909),r=e.i(74017),a=e.i(96250),n=e.i(59756),o=e.i(61916),i=e.i(74677),s=e.i(69741),l=e.i(16795),d=e.i(87718),p=e.i(95169),c=e.i(47587),u=e.i(66012),x=e.i(70101),g=e.i(26937),m=e.i(10372),h=e.i(93695);e.i(20232);var f=e.i(5232),b=e.i(46245),y=e.i(69719);let w=y.z.object({companyName:y.z.string().min(1,"Company name is required"),contactPerson:y.z.string().min(1,"Contact person is required"),email:y.z.string().email("Valid email is required"),phone:y.z.string().min(1,"Telephone number is required"),attendees:y.z.coerce.number().int().min(1,"Number of attendees must be at least 1"),eventDate:y.z.string().min(1,"Event date is required"),details:y.z.string().optional()});async function v(e){let t,r=new b.Resend(process.env.RESEND_API_KEY);try{t=await e.json()}catch{return Response.json({error:"Invalid request body"},{status:400})}let a=w.safeParse(t);if(!a.success)return Response.json({error:a.error.issues[0]?.message??"Invalid form data"},{status:400});let{companyName:n,contactPerson:o,email:i,phone:s,attendees:l,eventDate:d,details:p}=a.data,c=new Date().toLocaleString("en-GB",{timeZone:"Europe/London"}),u=new Date(d).toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"}),{error:x}=await r.emails.send({from:"Barnes Bowling Club <noreply@barnesbowling.com>",to:"info@barnesbowling.com",replyTo:i,subject:`New corporate hire enquiry — ${n}`,html:`
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#f0ede6;font-family:Arial,Helvetica,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0ede6;padding:32px 16px">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%">

        <!-- Header -->
        <tr>
          <td style="background:#1b3b26;padding:28px 36px">
            <p style="margin:0;font-family:Georgia,serif;font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:rgba(201,168,76,.85)">Barnes Bowling Club</p>
            <h1 style="margin:8px 0 0;font-family:Georgia,serif;font-size:22px;font-weight:400;color:#f5f0e8">New Corporate Hire Enquiry</h1>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="background:#fff;padding:36px">
            <table width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;line-height:1.6;color:#1a2e1f;border-collapse:collapse">
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;width:160px;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Company</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2;font-weight:500">${n}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Contact Person</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${o}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Email</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2"><a href="mailto:${i}" style="color:#1b3b26">${i}</a></td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Telephone</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${s}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Attendees</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${l}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Event Date</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${u}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Details</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2;white-space:pre-wrap">${p||"—"}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Submitted</td>
                <td style="padding:10px 0 10px 16px;color:#888">${c}</td>
              </tr>
            </table>

            <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:28px">
              <tr>
                <td>
                  <a href="mailto:${i}" style="display:inline-block;background:#1b3b26;color:#fff;text-decoration:none;font-size:12px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;padding:11px 24px">
                    Reply to Enquiry
                  </a>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="padding:20px 36px;font-size:11px;color:#999;line-height:1.6">
            Barnes Bowling Club \xb7 info@barnesbowling.com \xb7 The Sun Inn, Church Road, Barnes, London SW13 9HE
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`});return x?(console.error("Resend error:",x),Response.json({error:"Failed to send email. Please try again or contact us directly."},{status:500})):Response.json({ok:!0})}e.s(["POST",0,v],88405);var R=e.i(88405);let E=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/corporate-enquiry/route",pathname:"/api/corporate-enquiry",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/corporate-enquiry/route.ts",nextConfigOutput:"standalone",userland:R,...{}}),{workAsyncStorage:C,workUnitAsyncStorage:q,serverHooks:A}=E;async function P(e,t,a){a.requestMeta&&(0,n.setRequestMeta)(e,a.requestMeta),E.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let b="/api/corporate-enquiry/route";b=b.replace(/\/index$/,"")||"/";let y=await E.prepare(e,t,{srcPage:b,multiZoneDraftMode:!1});if(!y)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:w,deploymentId:v,params:R,nextConfig:C,parsedUrl:q,isDraftMode:A,prerenderManifest:P,routerServerContext:T,isOnDemandRevalidate:N,revalidateOnlyGenerated:S,resolvedPathname:k,clientReferenceManifest:_,serverActionsManifest:O}=y,j=(0,s.normalizeAppPath)(b),z=!!(P.dynamicRoutes[j]||P.routes[k]),D=async()=>((null==T?void 0:T.render404)?await T.render404(e,t,q,!1):t.end("This page could not be found"),null);if(z&&!A){let e=!!P.routes[k],t=P.dynamicRoutes[j];if(t&&!1===t.fallback&&!e){if(C.adapterPath)return await D();throw new h.NoFallbackError}}let H=null;!z||E.isDev||A||(H="/index"===(H=k)?"/":H);let I=!0===E.isDev||!z,$=z&&!I;O&&_&&(0,i.setManifestsSingleton)({page:b,clientReferenceManifest:_,serverActionsManifest:O});let B=e.method||"GET",U=(0,o.getTracer)(),M=U.getActiveScopeSpan(),F=!!(null==T?void 0:T.isWrappedByNextServer),K=!!(0,n.getRequestMeta)(e,"minimalMode"),L=(0,n.getRequestMeta)(e,"incrementalCache")||await E.getIncrementalCache(e,C,P,K);null==L||L.resetRequestCache(),globalThis.__incrementalCache=L;let G={params:R,previewProps:P.preview,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts},cacheComponents:!!C.cacheComponents,supportsDynamicResponse:I,incrementalCache:L,cacheLifeProfiles:C.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>E.onRequestError(e,t,a,n,T)},sharedContext:{buildId:w,deploymentId:v}},V=new l.NodeNextRequest(e),W=new l.NodeNextResponse(t),X=d.NextRequestAdapter.fromNodeNextRequest(V,(0,d.signalFromNodeResponse)(t));try{let n,i=async e=>E.handle(X,G).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=U.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${B} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",a),n.updateName(t))}else e.updateName(`${B} ${b}`)}),s=async n=>{var o,s;let l=async({previousCacheEntry:r})=>{try{if(!K&&N&&S&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await i(n);e.fetchMetrics=G.renderOpts.fetchMetrics;let s=G.renderOpts.pendingWaitUntil;s&&a.waitUntil&&(a.waitUntil(s),s=void 0);let l=G.renderOpts.collectedTags;if(!z)return await (0,u.sendResponse)(V,W,o,G.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,x.toNodeOutgoingHttpHeaders)(o.headers);l&&(t[m.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==G.renderOpts.collectedRevalidate&&!(G.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&G.renderOpts.collectedRevalidate,a=void 0===G.renderOpts.collectedExpire||G.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:G.renderOpts.collectedExpire;return{value:{kind:f.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await E.onRequestError(e,t,{routerKind:"App Router",routePath:b,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:$,isOnDemandRevalidate:N})},!1,T),t}},d=await E.handleResponse({req:e,nextConfig:C,cacheKey:H,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:P,isRoutePPREnabled:!1,isOnDemandRevalidate:N,revalidateOnlyGenerated:S,responseGenerator:l,waitUntil:a.waitUntil,isMinimalMode:K});if(!z)return null;if((null==d||null==(o=d.value)?void 0:o.kind)!==f.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(s=d.value)?void 0:s.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",N?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),A&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,x.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&z||p.delete(m.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,g.getCacheControlHeader)(d.cacheControl)),await (0,u.sendResponse)(V,W,new Response(d.value.body,{headers:p,status:d.value.status||200})),null};F&&M?await s(M):(n=U.getActiveScopeSpan(),await U.withPropagatedContext(e.headers,()=>U.trace(p.BaseServerSpan.handleRequest,{spanName:`${B} ${b}`,kind:o.SpanKind.SERVER,attributes:{"http.method":B,"http.target":e.url}},s),void 0,!F))}catch(t){if(t instanceof h.NoFallbackError||await E.onRequestError(e,t,{routerKind:"App Router",routePath:j,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:$,isOnDemandRevalidate:N})},!1,T),z)throw t;return await (0,u.sendResponse)(V,W,new Response(null,{status:500})),null}}e.s(["handler",0,P,"patchFetch",0,function(){return(0,a.patchFetch)({workAsyncStorage:C,workUnitAsyncStorage:q})},"routeModule",0,E,"serverHooks",0,A,"workAsyncStorage",0,C,"workUnitAsyncStorage",0,q],17980)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0k9h51r._.js.map