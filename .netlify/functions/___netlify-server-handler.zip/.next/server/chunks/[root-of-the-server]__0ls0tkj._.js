module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},79314,e=>{"use strict";let t=(0,e.i(24389).createClient)("https://wbvgbdyqfbvufysptgoj.supabase.co",process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:!1}});e.s(["supabaseAdmin",0,t])},72818,e=>{"use strict";var t=e.i(47909),r=e.i(74017),a=e.i(96250),n=e.i(59756),o=e.i(61916),i=e.i(74677),s=e.i(69741),l=e.i(16795),d=e.i(87718),p=e.i(95169),u=e.i(47587),c=e.i(66012),g=e.i(70101),x=e.i(26937),m=e.i(10372),h=e.i(93695);e.i(20232);var f=e.i(5232),b=e.i(46245),y=e.i(69719),w=e.i(79314);let v=y.z.object({title:y.z.string().optional(),firstName:y.z.string().min(1,"First name is required"),lastName:y.z.string().min(1,"Last name is required"),email:y.z.string().email("Valid email is required"),phone:y.z.string().optional(),heard:y.z.string().optional(),message:y.z.string().optional()});async function R(e){let t,r=new b.Resend(process.env.RESEND_API_KEY);try{t=await e.json()}catch{return Response.json({error:"Invalid request body"},{status:400})}let a=v.safeParse(t);if(!a.success)return Response.json({error:a.error.issues[0]?.message??"Invalid form data"},{status:400});let{title:n,firstName:o,lastName:i,email:s,phone:l,heard:d,message:p}=a.data,u=[n,o,i].filter(Boolean).join(" "),c=new Date().toLocaleString("en-GB",{timeZone:"Europe/London"}),{error:g}=await r.emails.send({from:"Barnes Bowling Club <noreply@barnesbowling.com>",to:"info@barnesbowling.com",replyTo:s,subject:`New membership enquiry — ${u}`,html:`
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#f0ede6;font-family:Arial,Helvetica,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0ede6;padding:32px 16px">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%">

        <!-- Header -->
        <tr>
          <td style="background:#1b3b26;padding:28px 36px">
            <p style="margin:0;font-family:Georgia,serif;font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:rgba(201,168,76,.85)">Barnes Bowling Club</p>
            <h1 style="margin:8px 0 0;font-family:Georgia,serif;font-size:22px;font-weight:400;color:#f5f0e8">New Membership Enquiry</h1>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="background:#fff;padding:36px">
            <table width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;line-height:1.6;color:#1a2e1f;border-collapse:collapse">
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;width:140px;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Name</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2;font-weight:500">${u}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Email</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2"><a href="mailto:${s}" style="color:#1b3b26">${s}</a></td>
              </tr>
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Phone</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${l||"—"}</td>
              </tr>
              ${d?`
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Heard via</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${d}</td>
              </tr>`:""}
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Message</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2;white-space:pre-wrap">${p||"—"}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Submitted</td>
                <td style="padding:10px 0 10px 16px;color:#888">${c}</td>
              </tr>
            </table>

            <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:28px">
              <tr>
                <td>
                  <a href="mailto:${s}" style="display:inline-block;background:#1b3b26;color:#fff;text-decoration:none;font-size:12px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;padding:11px 24px">
                    Reply to Enquiry
                  </a>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="padding:20px 36px;font-size:11px;color:#999;line-height:1.6">
            Barnes Bowling Club \xb7 info@barnesbowling.com \xb7 The Sun Inn, Church Road, Barnes, London SW13 9HE
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`});return g?(console.error("Resend error:",g),Response.json({error:"Failed to send email. Please try again or contact us directly."},{status:500})):(w.supabaseAdmin.from("applications").insert({name:u,email:s,phone:l??"",membership_type:"full",message:[d?`How did you hear about us: ${d}`:"",p??""].filter(Boolean).join("\n\n"),status:"new"}).then(void 0,()=>{}),Response.json({ok:!0}))}e.s(["POST",0,R],56240);var E=e.i(56240);let C=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/membership-enquiry/route",pathname:"/api/membership-enquiry",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/membership-enquiry/route.ts",nextConfigOutput:"standalone",userland:E,...{}}),{workAsyncStorage:A,workUnitAsyncStorage:q,serverHooks:S}=C;async function N(e,t,a){a.requestMeta&&(0,n.setRequestMeta)(e,a.requestMeta),C.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let b="/api/membership-enquiry/route";b=b.replace(/\/index$/,"")||"/";let y=await C.prepare(e,t,{srcPage:b,multiZoneDraftMode:!1});if(!y)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:w,deploymentId:v,params:R,nextConfig:E,parsedUrl:A,isDraftMode:q,prerenderManifest:S,routerServerContext:N,isOnDemandRevalidate:P,revalidateOnlyGenerated:T,resolvedPathname:_,clientReferenceManifest:k,serverActionsManifest:j}=y,O=(0,s.normalizeAppPath)(b),H=!!(S.dynamicRoutes[O]||S.routes[_]),I=async()=>((null==N?void 0:N.render404)?await N.render404(e,t,A,!1):t.end("This page could not be found"),null);if(H&&!q){let e=!!S.routes[_],t=S.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(E.adapterPath)return await I();throw new h.NoFallbackError}}let z=null;!H||C.isDev||q||(z="/index"===(z=_)?"/":z);let $=!0===C.isDev||!H,B=H&&!$;j&&k&&(0,i.setManifestsSingleton)({page:b,clientReferenceManifest:k,serverActionsManifest:j});let M=e.method||"GET",U=(0,o.getTracer)(),D=U.getActiveScopeSpan(),F=!!(null==N?void 0:N.isWrappedByNextServer),K=!!(0,n.getRequestMeta)(e,"minimalMode"),L=(0,n.getRequestMeta)(e,"incrementalCache")||await C.getIncrementalCache(e,E,S,K);null==L||L.resetRequestCache(),globalThis.__incrementalCache=L;let G={params:R,previewProps:S.preview,renderOpts:{experimental:{authInterrupts:!!E.experimental.authInterrupts},cacheComponents:!!E.cacheComponents,supportsDynamicResponse:$,incrementalCache:L,cacheLifeProfiles:E.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>C.onRequestError(e,t,a,n,N)},sharedContext:{buildId:w,deploymentId:v}},V=new l.NodeNextRequest(e),W=new l.NodeNextResponse(t),X=d.NextRequestAdapter.fromNodeNextRequest(V,(0,d.signalFromNodeResponse)(t));try{let n,i=async e=>C.handle(X,G).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=U.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${M} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",a),n.updateName(t))}else e.updateName(`${M} ${b}`)}),s=async n=>{var o,s;let l=async({previousCacheEntry:r})=>{try{if(!K&&P&&T&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await i(n);e.fetchMetrics=G.renderOpts.fetchMetrics;let s=G.renderOpts.pendingWaitUntil;s&&a.waitUntil&&(a.waitUntil(s),s=void 0);let l=G.renderOpts.collectedTags;if(!H)return await (0,c.sendResponse)(V,W,o,G.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,g.toNodeOutgoingHttpHeaders)(o.headers);l&&(t[m.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==G.renderOpts.collectedRevalidate&&!(G.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&G.renderOpts.collectedRevalidate,a=void 0===G.renderOpts.collectedExpire||G.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:G.renderOpts.collectedExpire;return{value:{kind:f.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await C.onRequestError(e,t,{routerKind:"App Router",routePath:b,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:P})},!1,N),t}},d=await C.handleResponse({req:e,nextConfig:E,cacheKey:z,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:S,isRoutePPREnabled:!1,isOnDemandRevalidate:P,revalidateOnlyGenerated:T,responseGenerator:l,waitUntil:a.waitUntil,isMinimalMode:K});if(!H)return null;if((null==d||null==(o=d.value)?void 0:o.kind)!==f.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(s=d.value)?void 0:s.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",P?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),q&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,g.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&H||p.delete(m.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,x.getCacheControlHeader)(d.cacheControl)),await (0,c.sendResponse)(V,W,new Response(d.value.body,{headers:p,status:d.value.status||200})),null};F&&D?await s(D):(n=U.getActiveScopeSpan(),await U.withPropagatedContext(e.headers,()=>U.trace(p.BaseServerSpan.handleRequest,{spanName:`${M} ${b}`,kind:o.SpanKind.SERVER,attributes:{"http.method":M,"http.target":e.url}},s),void 0,!F))}catch(t){if(t instanceof h.NoFallbackError||await C.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:B,isOnDemandRevalidate:P})},!1,N),H)throw t;return await (0,c.sendResponse)(V,W,new Response(null,{status:500})),null}}e.s(["handler",0,N,"patchFetch",0,function(){return(0,a.patchFetch)({workAsyncStorage:A,workUnitAsyncStorage:q})},"routeModule",0,C,"serverHooks",0,S,"workAsyncStorage",0,A,"workUnitAsyncStorage",0,q],72818)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0ls0tkj._.js.map