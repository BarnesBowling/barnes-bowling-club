module.exports=[18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},10044,e=>{"use strict";var t=e.i(47909),r=e.i(74017),a=e.i(96250),n=e.i(59756),o=e.i(61916),i=e.i(74677),s=e.i(69741),l=e.i(16795),d=e.i(87718),p=e.i(95169),c=e.i(47587),u=e.i(66012),g=e.i(70101),x=e.i(26937),m=e.i(10372),h=e.i(93695);e.i(20232);var f=e.i(5232),b=e.i(46245),y=e.i(69719);let w=y.z.object({title:y.z.string().optional(),firstName:y.z.string().min(1,"First name is required"),lastName:y.z.string().min(1,"Last name is required"),company:y.z.string().optional(),phone:y.z.string().optional(),email:y.z.string().email("Valid email is required"),message:y.z.string().min(1,"Please enter a message").max(1e3)});async function R(e){let t,r=new b.Resend(process.env.RESEND_API_KEY);try{t=await e.json()}catch{return Response.json({error:"Invalid request body"},{status:400})}let a=w.safeParse(t);if(!a.success)return Response.json({error:a.error.issues[0]?.message??"Invalid form data"},{status:400});let{title:n,firstName:o,lastName:i,company:s,phone:l,email:d,message:p}=a.data,c=[n,o,i].filter(Boolean).join(" "),u=new Date().toLocaleString("en-GB",{timeZone:"Europe/London"}),{error:g}=await r.emails.send({from:"Barnes Bowling Club <noreply@barnesbowling.com>",to:"info@barnesbowling.com",replyTo:d,subject:`New message from ${c}`,html:`
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#f0ede6;font-family:Arial,Helvetica,sans-serif">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0ede6;padding:32px 16px">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%">

        <tr>
          <td style="background:#1b3b26;padding:28px 36px">
            <p style="margin:0;font-family:Georgia,serif;font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:rgba(201,168,76,.85)">Barnes Bowling Club</p>
            <h1 style="margin:8px 0 0;font-family:Georgia,serif;font-size:22px;font-weight:400;color:#f5f0e8">New Contact Message</h1>
          </td>
        </tr>

        <tr>
          <td style="background:#fff;padding:36px">
            <table width="100%" cellpadding="0" cellspacing="0" style="font-size:14px;line-height:1.6;color:#1a2e1f;border-collapse:collapse">
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;width:140px;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Name</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2;font-weight:500">${c}</td>
              </tr>
              ${s?`
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Company</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${s}</td>
              </tr>`:""}
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Email</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2"><a href="mailto:${d}" style="color:#1b3b26">${d}</a></td>
              </tr>
              ${l?`
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Phone</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2">${l}</td>
              </tr>`:""}
              <tr>
                <td style="padding:10px 0;border-bottom:1px solid #eae8e2;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Message</td>
                <td style="padding:10px 0 10px 16px;border-bottom:1px solid #eae8e2;white-space:pre-wrap">${p}</td>
              </tr>
              <tr>
                <td style="padding:10px 0;color:#666;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:600;vertical-align:top">Submitted</td>
                <td style="padding:10px 0 10px 16px;color:#888">${u}</td>
              </tr>
            </table>

            <table width="100%" cellpadding="0" cellspacing="0" style="margin-top:28px">
              <tr>
                <td>
                  <a href="mailto:${d}" style="display:inline-block;background:#1b3b26;color:#fff;text-decoration:none;font-size:12px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;padding:11px 24px">
                    Reply to ${o}
                  </a>
                </td>
              </tr>
            </table>
          </td>
        </tr>

        <tr>
          <td style="padding:20px 36px;font-size:11px;color:#999;line-height:1.6">
            Barnes Bowling Club \xb7 info@barnesbowling.com \xb7 The Sun Inn, Church Road, Barnes, London SW13 9HE
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`});return g?(console.error("Resend error:",g),Response.json({error:"Failed to send your message. Please try again or email us directly."},{status:500})):Response.json({ok:!0})}e.s(["POST",0,R],91242);var v=e.i(91242);let E=new t.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/contact/route.ts",nextConfigOutput:"standalone",userland:v,...{}}),{workAsyncStorage:C,workUnitAsyncStorage:A,serverHooks:N}=E;async function P(e,t,a){a.requestMeta&&(0,n.setRequestMeta)(e,a.requestMeta),E.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let b="/api/contact/route";b=b.replace(/\/index$/,"")||"/";let y=await E.prepare(e,t,{srcPage:b,multiZoneDraftMode:!1});if(!y)return t.statusCode=400,t.end("Bad Request"),null==a.waitUntil||a.waitUntil.call(a,Promise.resolve()),null;let{buildId:w,deploymentId:R,params:v,nextConfig:C,parsedUrl:A,isDraftMode:N,prerenderManifest:P,routerServerContext:T,isOnDemandRevalidate:S,revalidateOnlyGenerated:q,resolvedPathname:k,clientReferenceManifest:_,serverActionsManifest:j}=y,O=(0,s.normalizeAppPath)(b),$=!!(P.dynamicRoutes[O]||P.routes[k]),z=async()=>((null==T?void 0:T.render404)?await T.render404(e,t,A,!1):t.end("This page could not be found"),null);if($&&!N){let e=!!P.routes[k],t=P.dynamicRoutes[O];if(t&&!1===t.fallback&&!e){if(C.adapterPath)return await z();throw new h.NoFallbackError}}let I=null;!$||E.isDev||N||(I="/index"===(I=k)?"/":I);let H=!0===E.isDev||!$,M=$&&!H;j&&_&&(0,i.setManifestsSingleton)({page:b,clientReferenceManifest:_,serverActionsManifest:j});let D=e.method||"GET",U=(0,o.getTracer)(),B=U.getActiveScopeSpan(),F=!!(null==T?void 0:T.isWrappedByNextServer),K=!!(0,n.getRequestMeta)(e,"minimalMode"),L=(0,n.getRequestMeta)(e,"incrementalCache")||await E.getIncrementalCache(e,C,P,K);null==L||L.resetRequestCache(),globalThis.__incrementalCache=L;let G={params:v,previewProps:P.preview,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts},cacheComponents:!!C.cacheComponents,supportsDynamicResponse:H,incrementalCache:L,cacheLifeProfiles:C.cacheLife,waitUntil:a.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,n)=>E.onRequestError(e,t,a,n,T)},sharedContext:{buildId:w,deploymentId:R}},V=new l.NodeNextRequest(e),W=new l.NodeNextResponse(t),X=d.NextRequestAdapter.fromNodeNextRequest(V,(0,d.signalFromNodeResponse)(t));try{let n,i=async e=>E.handle(X,G).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=U.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=r.get("next.route");if(a){let t=`${D} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t),n&&n!==e&&(n.setAttribute("http.route",a),n.updateName(t))}else e.updateName(`${D} ${b}`)}),s=async n=>{var o,s;let l=async({previousCacheEntry:r})=>{try{if(!K&&S&&q&&!r)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let o=await i(n);e.fetchMetrics=G.renderOpts.fetchMetrics;let s=G.renderOpts.pendingWaitUntil;s&&a.waitUntil&&(a.waitUntil(s),s=void 0);let l=G.renderOpts.collectedTags;if(!$)return await (0,u.sendResponse)(V,W,o,G.renderOpts.pendingWaitUntil),null;{let e=await o.blob(),t=(0,g.toNodeOutgoingHttpHeaders)(o.headers);l&&(t[m.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==G.renderOpts.collectedRevalidate&&!(G.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&G.renderOpts.collectedRevalidate,a=void 0===G.renderOpts.collectedExpire||G.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:G.renderOpts.collectedExpire;return{value:{kind:f.CachedRouteKind.APP_ROUTE,status:o.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:a}}}}catch(t){throw(null==r?void 0:r.isStale)&&await E.onRequestError(e,t,{routerKind:"App Router",routePath:b,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:S})},!1,T),t}},d=await E.handleResponse({req:e,nextConfig:C,cacheKey:I,routeKind:r.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:P,isRoutePPREnabled:!1,isOnDemandRevalidate:S,revalidateOnlyGenerated:q,responseGenerator:l,waitUntil:a.waitUntil,isMinimalMode:K});if(!$)return null;if((null==d||null==(o=d.value)?void 0:o.kind)!==f.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==d||null==(s=d.value)?void 0:s.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});K||t.setHeader("x-nextjs-cache",S?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),N&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,g.fromNodeOutgoingHttpHeaders)(d.value.headers);return K&&$||p.delete(m.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,x.getCacheControlHeader)(d.cacheControl)),await (0,u.sendResponse)(V,W,new Response(d.value.body,{headers:p,status:d.value.status||200})),null};F&&B?await s(B):(n=U.getActiveScopeSpan(),await U.withPropagatedContext(e.headers,()=>U.trace(p.BaseServerSpan.handleRequest,{spanName:`${D} ${b}`,kind:o.SpanKind.SERVER,attributes:{"http.method":D,"http.target":e.url}},s),void 0,!F))}catch(t){if(t instanceof h.NoFallbackError||await E.onRequestError(e,t,{routerKind:"App Router",routePath:O,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:M,isOnDemandRevalidate:S})},!1,T),$)throw t;return await (0,u.sendResponse)(V,W,new Response(null,{status:500})),null}}e.s(["handler",0,P,"patchFetch",0,function(){return(0,a.patchFetch)({workAsyncStorage:C,workUnitAsyncStorage:A})},"routeModule",0,E,"serverHooks",0,N,"workAsyncStorage",0,C,"workUnitAsyncStorage",0,A],10044)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0vffx9i._.js.map