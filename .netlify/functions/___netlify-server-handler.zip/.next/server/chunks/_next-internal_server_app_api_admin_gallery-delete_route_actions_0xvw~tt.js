module.exports=[52581,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_gallery-delete_route_actions_0xvw~tt.js.map