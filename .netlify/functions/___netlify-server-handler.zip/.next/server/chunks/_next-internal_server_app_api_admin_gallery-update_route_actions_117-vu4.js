module.exports=[57420,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_gallery-update_route_actions_117-vu4.js.map