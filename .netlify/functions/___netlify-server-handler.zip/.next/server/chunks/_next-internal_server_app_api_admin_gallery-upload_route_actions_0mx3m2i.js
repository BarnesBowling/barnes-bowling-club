module.exports=[52675,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_gallery-upload_route_actions_0mx3m2i.js.map