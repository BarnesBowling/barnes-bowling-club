module.exports=[74957,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_application-notify_route_actions_0avi493.js.map