module.exports=[62290,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_corporate-enquiry_route_actions_0tg4n69.js.map