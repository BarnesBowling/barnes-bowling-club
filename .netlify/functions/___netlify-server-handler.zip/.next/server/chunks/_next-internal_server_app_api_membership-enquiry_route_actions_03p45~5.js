module.exports=[75542,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_membership-enquiry_route_actions_03p45~5.js.map