module.exports=[25010,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payment_paypal-capture_route_actions_0o378w7.js.map