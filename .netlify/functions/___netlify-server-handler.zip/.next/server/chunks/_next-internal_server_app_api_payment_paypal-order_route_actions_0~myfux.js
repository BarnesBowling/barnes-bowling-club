module.exports=[96451,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_payment_paypal-order_route_actions_0~myfux.js.map