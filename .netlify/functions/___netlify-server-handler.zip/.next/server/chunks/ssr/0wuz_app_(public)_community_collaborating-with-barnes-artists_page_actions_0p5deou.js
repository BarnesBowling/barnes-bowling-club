module.exports=[32337,(a,b,c)=>{}];

//# sourceMappingURL=0wuz_app_%28public%29_community_collaborating-with-barnes-artists_page_actions_0p5deou.js.map