module.exports=[54799,(a,b,c)=>{b.exports=a.x("crypto",()=>require("crypto"))},27699,(a,b,c)=>{b.exports=a.x("events",()=>require("events"))},21517,(a,b,c)=>{b.exports=a.x("http",()=>require("http"))},24836,(a,b,c)=>{b.exports=a.x("https",()=>require("https"))},46786,(a,b,c)=>{b.exports=a.x("os",()=>require("os"))}];

//# sourceMappingURL=%5Bexternals%5D__01em6cm._.js.map