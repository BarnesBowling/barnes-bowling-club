module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},71306,(a,b,c)=>{b.exports=a.r(18622)},79847,a=>{a.n(a.i(3343))},9185,a=>{a.n(a.i(29432))},72842,a=>{a.n(a.i(75164))},54897,a=>{a.n(a.i(30106))},56157,a=>{a.n(a.i(18970))},94331,a=>{a.n(a.i(60644))},15988,a=>{a.n(a.i(56952))},25766,a=>{a.n(a.i(77341))},29725,a=>{a.n(a.i(94290))},90833,a=>{a.n(a.i(46994))},5785,a=>{a.n(a.i(90588))},74793,a=>{a.n(a.i(33169))},85826,a=>{a.n(a.i(37111))},21565,a=>{a.n(a.i(41763))},65911,a=>{a.n(a.i(8950))},25128,a=>{a.n(a.i(91562))},40781,a=>{a.n(a.i(49670))},69411,a=>{a.n(a.i(75700))},63081,a=>{a.n(a.i(276))},62837,a=>{a.n(a.i(40795))},34607,a=>{a.n(a.i(11614))},96338,a=>{a.n(a.i(21751))},50642,a=>{a.n(a.i(12213))},32242,a=>{a.n(a.i(22693))},88530,a=>{a.n(a.i(10531))},8583,a=>{a.n(a.i(1082))},38534,a=>{a.n(a.i(98175))},70408,a=>{a.n(a.i(9095))},22922,a=>{a.n(a.i(96772))},78294,a=>{a.n(a.i(71717))},16625,a=>{a.n(a.i(85034))},88648,a=>{a.n(a.i(68113))},51914,a=>{a.n(a.i(66482))},25466,a=>{a.n(a.i(91505))},56845,a=>{"use strict";a.s(["Navbar",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call Navbar() from the server but Navbar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Navbar.tsx <module evaluation>","Navbar")},98677,a=>{"use strict";a.s(["Navbar",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call Navbar() from the server but Navbar is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Navbar.tsx","Navbar")},44425,a=>{"use strict";a.i(56845);var b=a.i(98677);a.n(b)},40471,a=>{"use strict";a.s(["Footer",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call Footer() from the server but Footer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx <module evaluation>","Footer")},34497,a=>{"use strict";a.s(["Footer",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call Footer() from the server but Footer is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/Footer.tsx","Footer")},91677,a=>{"use strict";a.i(40471);var b=a.i(34497);a.n(b)},48022,a=>{"use strict";a.s(["pastCaptains",0,[{year:2026,name:"Alaric Evans"},{year:2025,name:"Alaric Evans"},{year:2024,name:"Annie Watts"},{year:2023,name:"Annie Watts"},{year:2022,name:"TBD"},{year:2021,name:"TBD"},{year:2020,name:"TBD"},{year:2019,name:"TBD"},{year:2018,name:"TBD"},{year:2017,name:"TBD"},{year:2016,name:"TBD"},{year:2015,name:"TBD"},{year:2014,name:"TBD"},{year:2013,name:"TBD"},{year:2012,name:"TBD"},{year:2011,name:"TBD"},{year:2010,name:"TBD"},{year:2009,name:"TBD"},{year:2008,name:"TBD"},{year:2007,name:"TBD"},{year:2006,name:"TBD"},{year:2005,name:"TBD"},{year:2004,name:"TBD"},{year:2003,name:"TBD"},{year:2002,name:"TBD"},{year:2001,name:"TBD"},{year:2e3,name:"TBD"},{year:1999,name:"TBD"},{year:1998,name:"TBD"},{year:1997,name:"TBD"},{year:1996,name:"TBD"},{year:1995,name:"TBD"},{year:1994,name:"TBD"},{year:1993,name:"TBD"},{year:1992,name:"TBD"},{year:1991,name:"TBD"},{year:1990,name:"TBD"},{year:1989,name:"TBD"},{year:1988,name:"TBD"},{year:1987,name:"TBD"},{year:1986,name:"TBD"},{year:1985,name:"TBD"},{year:1984,name:"TBD"},{year:1983,name:"TBD"},{year:1982,name:"TBD"},{year:1981,name:"TBD"},{year:1980,name:"TBD"},{year:1979,name:"TBD"},{year:1978,name:"TBD"},{year:1977,name:"TBD"}],"pastPresidents",0,[{year:2026,name:"Judith Heaton"},{year:2025,name:"Jeremy Frearson"},{year:2024,name:"Catherine Mitrenas"},{year:2023,name:"Gerry Summers"},{year:2022,name:"John Stutfield"},{year:2021,name:"Ginnette Grimes"},{year:2020,name:"Annie Watts"},{year:2019,name:"Gary Lowry"},{year:2018,name:"Maggie Bell (voted in by membership as no president in post to gift as per constitution)"},{year:2017,name:"Pete Rees (stepped down mid-season)"},{year:2016,name:"Jeremy Fordham"},{year:2015,name:"Dinshaw Jilla"},{year:2014,name:"Gareth Ballance"},{year:2013,name:"Neale Freeland"},{year:2012,name:"George Papanicola"},{year:2011,name:"Frank Grimes"},{year:2010,name:"Roger McGough"},{year:2009,name:"TBD"},{year:2008,name:"TBD"},{year:2007,name:"TBD"},{year:2006,name:"TBD"},{year:2005,name:"TBD"},{year:2004,name:"TBD"},{year:2003,name:"TBD"},{year:2002,name:"TBD"},{year:2001,name:"TBD"},{year:2e3,name:"TBD"},{year:1999,name:"TBD"},{year:1998,name:"TBD"},{year:1997,name:"TBD"},{year:1996,name:"TBD"},{year:1995,name:"TBD"},{year:1994,name:"TBD"},{year:1993,name:"TBD"},{year:1992,name:"TBD"},{year:1991,name:"TBD"},{year:1990,name:"TBD"},{year:1989,name:"TBD"},{year:1988,name:"TBD"},{year:1987,name:"TBD"},{year:1986,name:"TBD"},{year:1985,name:"TBD"},{year:1984,name:"TBD"},{year:1983,name:"TBD"},{year:1982,name:"TBD"},{year:1981,name:"TBD"},{year:1980,name:"TBD"},{year:1979,name:"TBD"},{year:1978,name:"TBD"},{year:1977,name:"TBD"}]])},4178,a=>{"use strict";var b=a.i(7997),c=a.i(44425),d=a.i(91677),e=a.i(48022);a.s(["default",0,function(){return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{children:`
        .timeline-wrap {
          position: relative;
          padding: 2rem 0 3rem;
        }
        .timeline-wrap::before {
          content: '';
          position: absolute;
          left: 50%;
          transform: translateX(-50%);
          top: 0;
          bottom: 0;
          width: 2px;
          background: linear-gradient(to bottom, #A89560 0%, rgba(168,149,96,0.25) 100%);
        }
        .tl-entry {
          display: flex;
          align-items: center;
          min-height: 48px;
          position: relative;
        }
        .tl-entry.tl-left  { flex-direction: row; }
        .tl-entry.tl-right { flex-direction: row-reverse; }
        .tl-content {
          flex: 0 0 calc(50% - 24px);
          padding: 6px 20px;
        }
        .tl-entry.tl-left  .tl-content { text-align: right; }
        .tl-entry.tl-right .tl-content { text-align: left; }
        .tl-dot {
          flex: 0 0 12px;
          height: 12px;
          border-radius: 50%;
          background: #A89560;
          border: 2px solid #C4AF80;
          z-index: 1;
          box-shadow: 0 0 0 3px rgba(168,149,96,0.15);
        }
        .tl-spacer {
          flex: 0 0 calc(50% - 24px);
        }
        .tl-year {
          font-family: 'DM Sans', sans-serif;
          font-size: 11px;
          font-weight: 600;
          letter-spacing: .1em;
          text-transform: uppercase;
          color: #A89560;
          margin-bottom: 2px;
        }
        .tl-name {
          font-family: 'Playfair Display', serif;
          font-size: 16px;
          font-weight: 500;
          color: var(--text-dark);
          line-height: 1.3;
        }
        .tl-name.tl-tbd {
          color: var(--text-muted);
          font-style: italic;
          font-size: 14px;
        }
        @media (max-width: 600px) {
          .timeline-wrap::before {
            left: 20px;
          }
          .tl-entry.tl-left,
          .tl-entry.tl-right {
            flex-direction: row;
          }
          .tl-spacer { display: none; }
          .tl-dot { margin: 0 12px 0 14px; }
          .tl-content {
            flex: 1;
            text-align: left !important;
            padding: 6px 8px 6px 0;
          }
        }
      `}),(0,b.jsx)(c.Navbar,{}),(0,b.jsxs)("main",{children:[(0,b.jsx)("div",{style:{background:"var(--green-deep)",padding:"1rem 2rem 4rem",color:"var(--cream)"},children:(0,b.jsxs)("div",{className:"section-inner",children:[(0,b.jsx)("div",{style:{display:"flex",gap:"8px",alignItems:"center",marginBottom:"0.5rem"},children:(0,b.jsx)("a",{href:"/members/archive",className:"section-tag",style:{color:"var(--gold)",borderTopColor:"var(--gold)",textDecoration:"none",marginBottom:0},children:"Archive"})}),(0,b.jsxs)("h1",{className:"section-h2",style:{color:"var(--cream)",fontSize:"clamp(1.75rem,4vw,2.75rem)"},children:["Past ",(0,b.jsx)("em",{style:{color:"var(--gold)",fontStyle:"italic"},children:"Captains"})]}),(0,b.jsxs)("p",{className:"section-lead",style:{color:"rgba(245,240,232,.65)"},children:[(0,b.jsx)("em",{style:{color:"var(--gold)",fontStyle:"italic"},children:"Captains"})," of Barnes Bowling Club, 1977 to present."]})]})}),(0,b.jsxs)("div",{className:"section-inner",style:{padding:"3rem 2rem 5rem"},children:[(0,b.jsx)("div",{className:"timeline-wrap",children:e.pastCaptains.map((a,c)=>{let d="TBD"===a.name;return(0,b.jsxs)("div",{className:`tl-entry ${c%2==0?"tl-left":"tl-right"}`,children:[(0,b.jsxs)("div",{className:"tl-content",children:[(0,b.jsx)("div",{className:"tl-year",children:a.year}),(0,b.jsx)("div",{className:`tl-name${d?" tl-tbd":""}`,children:d?"To be added":a.name})]}),(0,b.jsx)("div",{className:"tl-dot"}),(0,b.jsx)("div",{className:"tl-spacer"})]},a.year)})}),(0,b.jsxs)("div",{style:{display:"flex",gap:"2rem",marginTop:"1rem",flexWrap:"wrap"},children:[(0,b.jsx)("a",{href:"/members/archive",style:{fontFamily:"'DM Sans', sans-serif",fontSize:"13px",color:"var(--green-mid)",textDecoration:"none",letterSpacing:".05em"},children:"← Back to Archive"}),(0,b.jsx)("a",{href:"/members/dashboard",style:{fontFamily:"'DM Sans', sans-serif",fontSize:"13px",color:"var(--text-muted)",textDecoration:"none",letterSpacing:".05em"},children:"← Back to dashboard"})]})]})]}),(0,b.jsx)(d.Footer,{})]})},"metadata",0,{title:"Past Captains — Barnes Bowling Club"}])},97565,a=>{a.n(a.i(4178))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__08skmvb._.js.map