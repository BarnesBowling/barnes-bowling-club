module.exports=[81707,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_apply_page_actions_0e63-sb.js.map