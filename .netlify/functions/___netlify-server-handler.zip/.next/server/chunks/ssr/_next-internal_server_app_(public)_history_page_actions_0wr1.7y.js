module.exports=[77729,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_history_page_actions_0wr1.7y.js.map