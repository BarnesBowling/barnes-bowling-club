module.exports=[13018,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_how-to-play_page_actions_01.yvso.js.map