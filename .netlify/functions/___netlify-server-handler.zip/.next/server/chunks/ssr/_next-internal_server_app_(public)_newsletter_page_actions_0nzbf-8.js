module.exports=[12822,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_newsletter_page_actions_0nzbf-8.js.map