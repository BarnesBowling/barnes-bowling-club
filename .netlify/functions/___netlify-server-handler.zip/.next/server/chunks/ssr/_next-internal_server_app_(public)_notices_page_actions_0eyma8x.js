module.exports=[62996,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_notices_page_actions_0eyma8x.js.map