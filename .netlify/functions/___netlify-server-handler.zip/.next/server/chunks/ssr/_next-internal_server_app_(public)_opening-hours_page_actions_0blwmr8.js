module.exports=[82311,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_opening-hours_page_actions_0blwmr8.js.map