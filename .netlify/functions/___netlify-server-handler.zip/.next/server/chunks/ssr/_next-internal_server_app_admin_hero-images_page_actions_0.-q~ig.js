module.exports=[93910,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_hero-images_page_actions_0.-q~ig.js.map