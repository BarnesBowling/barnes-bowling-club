module.exports=[64079,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_general-committee_page_actions_0cgjo6s.js.map