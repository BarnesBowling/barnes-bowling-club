module.exports=[96759,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_handicap-committee_page_actions_0b-o9b5.js.map