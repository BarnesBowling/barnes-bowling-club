module.exports=[53150,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_members_archive_captains_page_actions_0wa63n_.js.map