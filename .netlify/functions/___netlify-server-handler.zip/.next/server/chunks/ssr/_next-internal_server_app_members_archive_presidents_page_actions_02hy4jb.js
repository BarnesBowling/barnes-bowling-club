module.exports=[74721,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_members_archive_presidents_page_actions_02hy4jb.js.map