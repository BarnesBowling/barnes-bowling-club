module.exports=[81473,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_members_competition-sheets_page_actions_079ip41.js.map