module.exports=[1254,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_members_competitions_page_actions_08jr_jw.js.map