module.exports=[76640,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_members_constitution_page_actions_0wu-gm1.js.map