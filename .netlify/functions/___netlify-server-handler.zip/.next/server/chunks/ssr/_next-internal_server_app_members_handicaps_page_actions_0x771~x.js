module.exports=[12237,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_members_handicaps_page_actions_0x771~x.js.map