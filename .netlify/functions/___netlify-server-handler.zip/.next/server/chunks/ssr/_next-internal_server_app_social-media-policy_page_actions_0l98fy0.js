module.exports=[11785,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_social-media-policy_page_actions_0l98fy0.js.map