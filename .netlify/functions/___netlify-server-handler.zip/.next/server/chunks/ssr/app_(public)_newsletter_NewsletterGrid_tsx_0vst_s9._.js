module.exports=[66378,a=>{"use strict";var b=a.i(87924),c=a.i(72131);a.s(["NewsletterGrid",0,function({issues:a}){let[d,e]=(0,c.useState)(null);(0,c.useEffect)(()=>{if(!d)return;let a=a=>{"Escape"===a.key&&e(null)};return window.addEventListener("keydown",a),()=>window.removeEventListener("keydown",a)},[d]);let f=(0,c.useCallback)(a=>{"image"===a.type?e(a):window.open(a.pdf??a.src,"_blank")},[]);return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("style",{children:`
        .nl-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 2rem;
        }
        @media (max-width: 600px) {
          .nl-grid { grid-template-columns: 1fr; }
        }
        .nl-card {
          cursor: pointer;
          background: #fff;
          border-radius: 2px;
          overflow: hidden;
          box-shadow: 3px 3px 10px rgba(0,0,0,0.10);
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .nl-card:hover {
          transform: translateY(-2px);
          box-shadow: 5px 5px 16px rgba(0,0,0,0.15);
        }
      `}),(0,b.jsx)("div",{className:"nl-grid",children:a.map(a=>(0,b.jsxs)("div",{className:"nl-card",onClick:()=>f(a),role:"button",tabIndex:0,onKeyDown:b=>{("Enter"===b.key||" "===b.key)&&f(a)},"aria-label":`Open ${a.title}`,children:[(0,b.jsx)("div",{style:{width:"100%",aspectRatio:"3/4",overflow:"hidden",background:"#e8e4dc"},children:(0,b.jsx)("img",{src:a.src,alt:a.title,style:{width:"100%",height:"100%",display:"block",objectFit:"cover",objectPosition:"top center"}})}),(0,b.jsxs)("div",{style:{padding:"0.75rem 1rem 1rem"},children:[(0,b.jsx)("div",{style:{fontFamily:"'Playfair Display', serif",fontSize:"15px",fontWeight:700,color:"var(--green-deep)",lineHeight:1.3},children:a.title}),(0,b.jsxs)("div",{style:{fontFamily:"'Optima', 'Helvetica Neue', Helvetica, Arial, sans-serif",fontSize:"12px",color:"rgba(45,90,61,0.65)",marginTop:"4px"},children:[a.date," · ",a.issue]})]})]},a.src))}),d&&(0,b.jsx)("div",{onClick:()=>e(null),style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.88)",zIndex:1e3,display:"flex",alignItems:"center",justifyContent:"center",padding:"2rem",cursor:"zoom-out"},children:(0,b.jsx)("img",{src:d.src,alt:d.title,onClick:a=>a.stopPropagation(),style:{maxWidth:"90vw",maxHeight:"90vh",objectFit:"contain",boxShadow:"0 8px 40px rgba(0,0,0,0.6)",cursor:"default"}})})]})}])}];

//# sourceMappingURL=app_%28public%29_newsletter_NewsletterGrid_tsx_0vst_s9._.js.map