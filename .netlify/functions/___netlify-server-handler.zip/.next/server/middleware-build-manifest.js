globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/cznYOoLJ0DNLs9n2B4FPa/_buildManifest.js",
    "static/cznYOoLJ0DNLs9n2B4FPa/_ssgManifest.js",
    "static/cznYOoLJ0DNLs9n2B4FPa/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0c9t~rt7oycq5.js",
    "static/chunks/0p620ysi~mhk8.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0z2rc_~8gqrx3.js",
    "static/chunks/turbopack-0oul-bni209l1.js"
  ]
};
