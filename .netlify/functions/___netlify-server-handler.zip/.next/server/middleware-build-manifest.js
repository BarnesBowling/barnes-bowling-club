globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Ruu7tD575gYB9I47ZCVVQ/_buildManifest.js",
    "static/Ruu7tD575gYB9I47ZCVVQ/_ssgManifest.js",
    "static/Ruu7tD575gYB9I47ZCVVQ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0wcpv8q-7z2oz.js",
    "static/chunks/0p620ysi~mhk8.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/10u3y4bw1ayzs.js",
    "static/chunks/0z2rc_~8gqrx3.js",
    "static/chunks/turbopack-0she~r3tqgzwx.js"
  ]
};
